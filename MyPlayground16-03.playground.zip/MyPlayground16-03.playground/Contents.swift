import UIKit


//
//  main.swift
//  Teste
//
//  Created by Igor Dourado  on 16/03/23
//

import Foundation

protocol EscolaGeral{
    var id : Int { get set }
}

struct EscolaIndividual : EscolaGeral{
    var id: Int
    
    var nome: String

}

protocol Funcionario{
    var registro : Int { get }
    var nome : String { get set }
    var cargo: String { get set }
    var salarioMensal : Float {get set}
    
}

struct Horista : Funcionario {
    var registro: Int
    var nome: String
    var cargo: String
    var valorHoras : Float
    var quantHoras : Float
    var salarioMensal : Float
    
}

struct Mensalista : Funcionario {
    var registro: Int
    
    var nome: String
    
    var cargo: String
    
    var salarioMensal : Float
    
    
   
}

extension Funcionario {
    func salario() -> String{
        return cargo == "Professor" ? (String(salarioMensal) + " R$ como horista da escola") : (String(salarioMensal) + " R$ como mensalista da escola")
    }
}





var dict = [Int : [Funcionario]]()

var esc1 : EscolaIndividual = EscolaIndividual(id: 100, nome: "Marista viamao")
var esc2 : EscolaIndividual = EscolaIndividual(id: 200, nome: "Marista ipiranga")
var esc3 : EscolaIndividual = EscolaIndividual(id: 300, nome: "Marista champagnat")
var esc4 : EscolaIndividual = EscolaIndividual(id: 400, nome: "Marista integrado")

var escolas = [Int: EscolaIndividual]()
escolas[100] = esc1
escolas[200] = esc2
escolas[300] = esc3
escolas[400] = esc4

var hor1 : Horista = Horista(registro: 1, nome: "Pr. Marcos Paulo", cargo: "Professor", valorHoras: 24, quantHoras: 160, salarioMensal: 24 * 160)
var hor2 : Horista = Horista(registro: 2, nome: "Pr. Carlos Eduardo", cargo: "Professor", valorHoras: 21, quantHoras: 124, salarioMensal: 21 * 124)
var hor3 : Horista = Horista(registro: 3, nome: "Pr. Igor Dourado", cargo: "Professor", valorHoras: 18, quantHoras: 160, salarioMensal: 18 * 160)
var hor4 : Horista = Horista(registro: 4, nome: "Pr. Pluto Dourado", cargo: "Professor", valorHoras: 29, quantHoras: 140, salarioMensal: 29 * 140)
var hor5 : Horista = Horista(registro: 5, nome: "Pr. Fabiano Alves", cargo: "Professor", valorHoras: 26, quantHoras: 55, salarioMensal: 26 * 55)
var hor6 : Horista = Horista(registro: 6, nome: "Pr. Yuri Alberto", cargo: "Professor", valorHoras: 15, quantHoras: 60, salarioMensal: 15 * 60)
var hor7 : Horista = Horista(registro: 7, nome: "Pra. Maria Augusta", cargo: "Professor", valorHoras: 20, quantHoras: 145, salarioMensal: 20 * 145)
var hor8 : Horista = Horista(registro: 8, nome: "Pra. Ana Luisa", cargo: "Professora", valorHoras: 26, quantHoras: 138, salarioMensal: 26 * 138)
var hor9 : Horista = Horista(registro: 9, nome: "Pra. Tatiana Maia", cargo: "Professor", valorHoras: 25, quantHoras: 120, salarioMensal: 25 * 120)
var hor10 : Horista = Horista(registro: 10, nome: "Pr. Vinicius Junior", cargo: "Professor", valorHoras: 31, quantHoras: 80, salarioMensal: 31 * 80)
var hor11 : Horista = Horista(registro: 11, nome: "Pr. Rodrygo Goes", cargo: "Professor", valorHoras: 24, quantHoras: 158, salarioMensal: 24 * 158)

func adic(pessoa: Funcionario, esco: EscolaIndividual){
    guard dict[esco.id] == nil else {
        let aux = dict[esco.id]! + [pessoa]
        dict.updateValue(aux, forKey: esco.id)
        return
    }
    dict[esco.id] = [pessoa]
}

func formata(){
    print("_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-" )
}


adic(pessoa: hor1, esco: esc1)
adic(pessoa: hor2, esco: esc2)
adic(pessoa: hor3, esco: esc2)
adic(pessoa: hor4, esco: esc3)
adic(pessoa: hor5, esco: esc4)
adic(pessoa: hor6, esco: esc3)
adic(pessoa: hor7, esco: esc1)
adic(pessoa: hor8, esco: esc2)
adic(pessoa: hor9, esco: esc4)
adic(pessoa: hor10, esco: esc4)
adic(pessoa: hor11, esco: esc1)



var mens1 : Mensalista = Mensalista(registro: 1, nome: "Marcio Silva", cargo: "Secretário", salarioMensal: 2350.5)
var mens2 : Mensalista = Mensalista(registro: 2, nome: "Ada Maria", cargo: "Secretária", salarioMensal: 2894)
var mens3 : Mensalista = Mensalista(registro: 3, nome: "Maria Alvina", cargo: "Apoio", salarioMensal: 3569)
var mens4 : Mensalista = Mensalista(registro: 4, nome: "Carlos Alberto", cargo: "Secretário", salarioMensal: 1692.5)
var mens5 : Mensalista = Mensalista(registro: 5, nome: "Joao Alves", cargo: "Apoio", salarioMensal: 2459.8)
var mens6 : Mensalista = Mensalista(registro: 6, nome: "Cristina Dourado", cargo: "Apoio", salarioMensal: 1312.3)
var mens7 : Mensalista = Mensalista(registro: 7, nome: "Appio Adriano", cargo: "Secretário", salarioMensal: 3703)
var mens8 : Mensalista = Mensalista(registro: 8, nome: "Julia Maria", cargo: "Secretária", salarioMensal: 2892)
var mens9 : Mensalista = Mensalista(registro: 9, nome: "Thais Melo", cargo: "Secretária", salarioMensal: 2782.5)
var mens10 : Mensalista = Mensalista(registro: 10, nome: "Vivaldo Peba", cargo: "Apoio", salarioMensal: 2004.5)
var mens11 : Mensalista = Mensalista(registro: 11, nome: "Chiara Picon", cargo: "Apoio", salarioMensal: 1924.2)
var mens12 : Mensalista = Mensalista(registro: 12, nome: "Julio Duran", cargo: "Secretário", salarioMensal: 2452.4)


adic(pessoa: mens1, esco: esc1)
adic(pessoa: mens2, esco: esc2)
adic(pessoa: mens3, esco: esc2)
adic(pessoa: mens4, esco: esc3)

adic(pessoa: mens5, esco: esc4)
adic(pessoa: mens6, esco: esc3)
adic(pessoa: mens7, esco: esc1)
adic(pessoa: mens8, esco: esc2)
adic(pessoa: mens9, esco: esc4)
adic(pessoa: mens10, esco: esc4)
adic(pessoa: mens11, esco: esc1)
adic(pessoa: mens12, esco: esc3)

var gastoAnual : Float = 0.0
for x in dict.keys{
    var gastoMensal : Float = 0.0
    formata()
    print("Escola \(escolas[x]!.nome):")
    for aux in dict[x]!{
        print("Salário do(a) \(aux.cargo) \(aux.nome)  é de \(aux.salario())  ")
        gastoMensal += aux.salarioMensal
    }
    print("\nGasto Mensal da escola \(escolas[x]!.nome) é de \(gastoMensal) R$ ")
    gastoAnual += gastoMensal
}
formata()
print("Previsão de gasto anual de toda a rede Marista de escolas: \(gastoAnual*12) R$ ")
formata()
